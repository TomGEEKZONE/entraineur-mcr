# Entraîneur MCR — La Baie de Jade

Version **V0.5.3** — Bibliothèque « Ressources ».

## Nouveautés
- Onglet **Ressources** dans l'application, accessible à tous les niveaux.
- Trois PDF conservés **octet pour octet** dans `ressources/` : Mémo 01, Mémo 02 et Fiche des 81 combinaisons.
- Boutons Consulter et Télécharger pour chaque PDF.
- Aucun changement apporté au moteur MCR, aux 42 illustrations, au format de sauvegarde ou aux niveaux.

## Installation depuis un iPhone (méthode ZIP + GitHub Actions)
1. Créer un dépôt public `entraineur-mcr` sur GitHub.
2. Dans Safari, utiliser **uploading an existing file** pour envoyer l'archive `Entraineur_MCR_V0_5_3_GitHub_Pages.zip` à la racine du dépôt, puis Commit changes.
3. Settings > Pages > Build and deployment > Source : **GitHub Actions**.
4. Depuis **create your own**, créer `.github/workflows/deploy.yml` contenant le workflow fourni dans le fichier d'accompagnement téléchargeable. Le script décompresse l'archive ZIP, puis la publie.
5. La nouvelle adresse sera `https://VOTRE-PSEUDO.github.io/entraineur-mcr/` après un déploiement réussi.

## Sauvegarde
Les progrès sont dans le localStorage du navigateur. Le passage du domaine Netlify au domaine GitHub Pages nécessite un export JSON depuis l'ancien site, puis une importation dans le nouveau site. **Ne jamais téléverser les sauvegardes personnelles dans le dépôt public.**

## Documents publics
GitHub Pages est public : chaque PDF, le code et les 42 illustrations sont accessibles aux visiteurs du site. Vérifier la permission de diffusion avant de publier.

## Référentiel MCR
Le contenu des PDF est reproduit tel que fourni. Leur présence dans les Ressources ne constitue pas une certification réglementaire ; en cas de doute, consulter les règles WMO/EMA applicables.
