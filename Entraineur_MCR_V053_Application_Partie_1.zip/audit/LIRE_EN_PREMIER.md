# Contrôle automatique — Entraîneur MCR V0.2

**État du contrôle : 11 novembre 2026.**

## Résultat du premier passage

- **20 fans lus directement dans `data.js`** et comparés aux valeurs du référentiel de contrôle.
- **15 exemples structurellement conformes aux règles de reconnaissance codées**, ce qui n'est pas une homologation de leur totalité pédagogique.
- **5 exemples conditionnels** : les fans 62, 77, 78, 79 et 80 demandent davantage de contexte pour une vérification complète.
- **0 erreur structurelle détectée** par ces contrôles sur V0.2.
- **2 400 variantes d’exemples tirées et vérifiées** (120 par fan ; contrôle structurel, nombre physique de copies, unicité du marqueur HU).
- **19/19 contre-exemples rejetés** par le vérificateur, dont le décalage de deux rangs interdit au fan 51.
- **42 images PNG contrôlées par SHA-256** et noms de tuiles conformes aux références incluses.
- La V0.1 ancienne est **rejetée** avec deux erreurs liées au fan 51, preuve d'une régression effectivement détectable.

## Ce que teste réellement l'outil

1. Lecture du vrai catalogue de l'application, sans recopier ses données dans le rapport.
2. Identifiants, noms anglais de référence, valeurs des 20 fans, unicité des identifiants.
3. Validité des identifiants de tuiles, fichiers PNG, empreintes SHA-256, limite physique de quatre exemplaires et taille des exemples qualifiés de mains complètes.
4. Reconnaissance des structures propres aux 20 fans présents (familles, Chows consécutifs, Pungs, paires, superposition et décalage).
5. Tests négatifs conçus pour vérifier que des motifs trompeurs sont rejetés.
6. Modification des explications : le changement d'un texte est signalé pour relecture (empreinte de référence ; ce n'est **pas** une preuve de correction de la version initiale).

## Pourquoi cinq fans demeurent conditionnels

- **80 — Tirer soi-même :** la provenance de la tuile gagnante ne se déduit pas de son image.
- **77, 78, 79 — Les attentes :** un fragment avec tuile HU ne prouve pas l'unicité de l'attente sur la main complète.
- **62 — Tout Caché Donné :** l'état caché/exposé des figures et la victoire sur défausse doivent être exprimés explicitement dans un scénario de jeu vérifiable.

Les descriptions textuelles actuellement présentes dans l'application évoquent ces situations, mais leur présence dans une phrase ne constitue pas un contrôle indépendant.

## Comment exécuter l'audit

Avec Node.js (aucun paquet externe requis), depuis le dossier contenant `index.html` :

```bash
node audit/verify.mjs
node audit/verify.mjs --json audit/dernier_rapport.json
```

- **Code de sortie 0** : aucune erreur détectée par les tests implémentés ; les avertissements sont imprimés.
- **Code de sortie 1** : au moins une erreur détectée. En intégration continue, cela peut bloquer la publication.
- Pour exiger également zéro avertissement :

```bash
node audit/verify.mjs --strict
```

**Le mode strict échoue actuellement** du fait des cinq contextes non encore validés. C'est intentionnel et plus prudent qu'un « tout est validé » trompeur.

Pour contrôler une autre version, copie son `data.js` avec ses `assets/` dans le même dossier et relance l'audit. Les nouveaux fans devront être ajoutés au référentiel de contrôle après vérification des sources.

## Limites importantes

- Le système n'a testé que les **20 fans intégrés à la V0.1.1**, pas les 81 du règlement.
- Il ne calcule **pas** automatiquement tous les fans d'une main gagnante, leurs cumuls ou leurs exclusions. Il contrôle des motifs pédagogiques.
- Il ne certifie ni l'interprétation des règles, ni le sens de toutes les phrases, ni les scénarios réels de victoire, ni les futures modifications des sources.
- Les assertions indépendantes sont une traduction *humaine* du règlement en tests. Leur validité doit être revue en cas de mise à jour officielle ou de désaccord d'arbitrage.
- Les résultats sont des **contrôles locaux**. Ils ne s'exécutent pas spontanément sur Netlify après un simple glisser-déposer d'un ZIP. Un dépôt et un pipeline de déploiement doivent déclencher la commande à chaque version.

## Sources réglementaires

1. WMO, *Mahjong Competition Rules* (« Green Book »), édition 2006, publiée par l'EMA : https://mahjong-europe.org/portal/images/docs/mcr_ENa5.pdf
2. FFMJ, *Règles MCR — Description des combinaisons*, mai 2013, notamment p. 16 pour le fan 51 : https://www.ffmahjong.fr/FFMJ-site/documents/GuideFFMJ_MCR.pdf
3. EMA, page MCR (mise à jour indiquée au 20 avril 2026) : https://mahjong-europe.org/portal/index.php?Itemid=167&id=31&option=com_content&view=article

D'autres clarifications de compétition peuvent être pertinentes ; ce kit ne prétend pas les avoir toutes exhaustivement recensées.
