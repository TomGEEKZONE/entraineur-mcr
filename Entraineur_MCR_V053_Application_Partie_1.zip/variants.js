/* Entraîneur MCR — Variantes illustratives réglementairement bornées.
   Chaque variante conserve l'identité du fan. La validation complète d'une main
   et des circonstances de victoire reste distincte du motif pédagogique. */
(function(root){
'use strict';
const SUITS=['B','C','D'];
const SUIT_LABEL={B:'Bambous',C:'Caractères',D:'Cercles'};
const DRAGONS=['DR','DG','DW'];
const WIND=['WE','WS','WW','WN'];
function randomInt(max,rng){return Math.floor(rng()*max);}
function shuffled(items,rng){const a=items.slice();for(let i=a.length-1;i>0;i--){const j=randomInt(i+1,rng);[a[i],a[j]]=[a[j],a[i]];}return a;}
function pattern(s,start){return [s+start,s+(start+1),s+(start+2)];}
function permutation(groups, map){return groups.map(g=>g.map(code=>{const hu=code.endsWith('!');const k=hu?code.slice(0,-1):code;return (map[k]||k)+(hu?'!':'');}));}
function deepCopy(groups){return groups.map(g=>g.slice());}
function optionsFor(f,rng){
 const order=shuffled(SUITS,rng),s=order[0],s2=order[1],s3=order[2];
 const one=()=>1+randomInt(9,rng);
 const start=()=>1+randomInt(7,rng);
 const n1=()=>rng()<.5?1:9;
 let groups=null,prompt=null;
 switch(f.id){
 case 70:{let n=start();groups=[pattern(s,n),pattern(s2,n)];prompt='Deux chows de mêmes numéros dans deux familles différentes : quel fan reconnais-tu ?';break;}
 case 69:{let n=start();groups=[pattern(s,n),pattern(s,n)];prompt='Deux chows identiques dans la même famille : quel fan ?';break;}
 case 71:{let n=1+randomInt(4,rng);groups=[pattern(s,n),pattern(s,n+3)];prompt='Deux chows qui forment six numéros consécutifs dans une famille : quel fan ?';break;}
 case 72:groups=[pattern(s,1),pattern(s,7)];prompt='Un chow 1-2-3 et un chow 7-8-9 dans une seule famille : quel fan ?';break;
 case 73:{if(rng()<.5){let n=n1();groups=[[s+n,s+n,s+n]];prompt='Un pung de 1 ou de 9 dans une famille numérotée : quel fan simple ?';}else{groups=[['WE','WE','WE']];prompt='Un pung de Vent d’Est qui n’est ni ton Vent ni celui du tour : quel fan simple ?';}break;}
 case 59:{let d=DRAGONS[randomInt(DRAGONS.length,rng)];groups=[[d,d,d]];prompt='Trois dragons identiques forment un pung. Quel fan reconnais-tu ?';break;}
 case 80:{let n=one();groups=[[s+n+'!']];prompt='La victoire est obtenue par une tuile piochée soi-même. Quel fan de circonstance ?';break;}
 case 78:{let n=start();groups=[[s+n,s+(n+1)+'!',s+(n+2)]];prompt='Si c’est l’unique attente gagnante de la main, la tuile complète le milieu d’un chow. Quel fan ?';break;}
 case 79:{let n=one();groups=[[s+n,s+n+'!']];prompt='Si la paire est l’unique attente gagnante de la main : quel fan ?';break;}
 case 77:{let n=rng()<.5?1:7;groups=[n===1?[s+'1',s+'2',s+'3!']:[s+'7!',s+'8',s+'9']];prompt=n===1?'Si c’est la seule attente de la main, le 3 complète 1-2. Quel fan ?':'Si c’est la seule attente de la main, le 7 complète 8-9. Quel fan ?';break;}
 case 51:{let n=1+randomInt(5,rng);groups=[pattern(s,n),pattern(s2,n+1),pattern(s3,n+2)];prompt='Trois chows dans trois familles, décalés d’un rang exactement : quel fan de 6 points ?';break;}
 case 39:groups=[pattern(s,1),pattern(s2,4),pattern(s3,7)];prompt='1-2-3, 4-5-6 et 7-8-9, répartis dans trois familles : quel fan ?';break;
 case 28:groups=[pattern(s,1),pattern(s,4),pattern(s,7)];prompt='1-2-3, 4-5-6 et 7-8-9 dans une seule famille : quel fan ?';break;
 default:{
  const perm=Object.fromEntries(SUITS.flatMap((from,i)=>Array.from({length:9},(_,j)=>[from+(j+1),order[i]+(j+1)])));
  // Swap suit names bijectively: multiplicities and structures remain unchanged.
  // Permute wind identities for non-wind-specific whole-hand properties only.
  groups=permutation(f.groups,perm);
  if(f.id===75){
   const present=new Set(groups.flat().filter(code=>/^[BCD][1-9]/.test(code)).map(code=>code[0]));
   let missing=SUITS.filter(t=>!present.has(t));
   prompt=`Cette main ne contient aucun ${SUIT_LABEL[missing[0]]}. Quel fan décrit cette absence ?`;
  }
 }
 }
 return {groups,prompt:prompt||f.prompt};
}
function generate(f,previous='',rng=Math.random){
 const original=JSON.stringify(f.groups);
 let best;
 for(let i=0;i<30;i++){
  best=optionsFor(f,rng);
  const sig=JSON.stringify(best.groups);
  if(sig!==original && sig!==previous)break;
 }
 return {...f,groups:deepCopy(best.groups),prompt:best.prompt,variantKey:JSON.stringify(best.groups)};
}
root.MCR_VARIANTS={generate,optionsFor};
})(typeof window==='undefined'?globalThis:window);
