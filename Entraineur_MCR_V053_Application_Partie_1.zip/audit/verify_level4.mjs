/* Audit structurel indépendant des 10 fiches de cumuls, exécuté avec Node.js.
   Les assertions couvrent seulement les deux fans visés dans chaque exercice,
   pas tous les fans de la main ni les circonstances de HU. */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx=vm.createContext({window:{},console});
for(const f of ['data.js','combos.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f});
const {MCR_DATA:fanList,MCR_COMBOS:combos}=ctx.window;
const fanmap=Object.fromEntries(fanList.map(f=>[f.id,f]));
let checks=0;function check(condition,message){checks++;if(!condition)throw Error(message);}
const suit=t=>/^[BCD][1-9]$/.test(t),honor=t=>/^(?:WE|WS|WW|WN|DR|DG|DW)$/.test(t),wind=t=>/^W[ESWN]$/.test(t),dragon=t=>/^D[RGW]$/.test(t);
function chow(g){return g.length===3&&g.every(suit)&&g.every(t=>t[0]===g[0][0])&&Number(g[1][1])===Number(g[0][1])+1&&Number(g[2][1])===Number(g[0][1])+2;}
function pung(g){return g.length===3&&g.every(t=>t===g[0]);}
function validatePhysical(groups){
 check(groups.length===5,'Not 5 elements');check(groups.slice(0,4).every(g=>chow(g)||pung(g)),'Malformed Chow/Pung');
 check(groups[4].length===2&&groups[4][0]===groups[4][1],'Malformed pair');
 const tiles=groups.flat();check(tiles.length===14,'Not 14 tiles');
 const counts={};for(const t of tiles){check(suit(t)||honor(t),'Unknown tile '+t);counts[t]=(counts[t]||0)+1;}
 check(Object.values(counts).every(n=>n<=4),'More than four copies');
}
function holds(fanId,groups){
 const tiles=groups.flat(),melds=groups.slice(0,4),presentSuits=new Set(tiles.filter(suit).map(t=>t[0]));
 const chows=melds.filter(chow);
 switch(fanId){
  case 63:return melds.every(chow)&&groups[4].every(suit);
  case 76:return tiles.every(suit);
  case 50:return presentSuits.size===1&&tiles.some(honor);
  case 75:return presentSuits.size<=2;
  case 52:return new Set(groups.map(g=>suit(g[0])?g[0][0]:wind(g[0])?'wind':dragon(g[0])?'dragon':'?')).size===5;
  case 59:return melds.some(g=>pung(g)&&dragon(g[0]));
  case 51:{for(let a=0;a<chows.length;a++)for(let b=a+1;b<chows.length;b++)for(let c=b+1;c<chows.length;c++){
    const tri=[chows[a],chows[b],chows[c]],ss=new Set(tri.map(g=>g[0][0])),ns=tri.map(g=>Number(g[0][1])).sort((x,y)=>x-y);
    if(ss.size===3&&ns[1]===ns[0]+1&&ns[2]===ns[1]+1)return true;
   }return false;}
  case 49:return melds.every(pung);
  case 39:{const found=chows.filter(g=>[1,4,7].includes(Number(g[0][1])));for(let a of found)for(let b of found)for(let c of found){const seq=[a,b,c];if(new Set(seq.map(g=>Number(g[0][1]))).size===3&&new Set(seq.map(g=>g[0][0])).size===3)return true;}return false;}
  case 28:{for(const s of ['B','C','D'])if([1,4,7].every(n=>chows.some(g=>g[0]===s+n)))return true;return false;}
  default:throw Error('Fan not audited '+fanId);
 }
}
check(combos.CASES.length===10,'Expected 10 scenarios');
const ids=new Set();const included = new Set(['63-76','50-75']);
for(const c of combos.CASES){
 check(!ids.has(c.id),'Duplicate id');ids.add(c.id);
 check(fanmap[c.a]&&fanmap[c.b],`Missing reference fan ${c.id}`);
 check(['both','onlyA'].includes(c.relation),'Unexpected relation');
 check(c.relation!=='onlyA'||included.has(`${c.a}-${c.b}`),'Unverified inclusion pair '+c.id);
 const signatures=new Set();
 for(let trial=0;trial<6;trial++){
  // The Fisher-Yates permutation of three suits has 3 × 2 = 6 outcomes.
  let draws=0;const rng=()=>draws++===0?(Math.floor(trial/2)+0.1)/3:(trial%2?0.9:0.1);
  const variant=combos.instantiate(c,rng);
  signatures.add(JSON.stringify(variant.groups));
  validatePhysical(variant.groups);
  check(holds(c.a,variant.groups),`Expected fan ${c.a} missing ${c.id}`);
  check(holds(c.b,variant.groups),`Expected fan ${c.b} missing ${c.id}`);
  const total=combos.projectedScore(c,fanmap);
  check(total===(c.relation==='both'?fanmap[c.a].points+fanmap[c.b].points:fanmap[c.a].points),`Bad targeted subtotal ${c.id}`);
 }
 const usedSuits=new Set(c.groups.flat().filter(suit).map(t=>t[0])).size;
 check(signatures.size===(usedSuits===1?3:6),`Unexpected distinct suit variants for ${c.id}`);
}
// Independent negative checks: physical validity alone does not prove fan validity.
let invalid=combos.CASES.find(c=>c.id==='shifted-allchows').groups.map(g=>g.slice());
invalid[1]=['D3','D4','D5'];invalid[2]=['B5','B6','B7'];
check(!holds(51,invalid),'Bad two-rank shift accepted');
invalid=combos.CASES.find(c=>c.id==='chows-nohonors').groups.map(g=>g.slice());invalid[4]=['WE','WE'];
check(!holds(63,invalid),'Honor pair accepted for All Chows');
check(!holds(76,invalid),'Honor pair accepted for No Honors');
const badPure=combos.CASES.find(c=>c.id==='purestraight-allchows').groups.map(g=>g.slice());badPure[1]=['D4','D5','D6'];
check(!holds(28,badPure),'Three suits accepted as Pure Straight');
console.log(JSON.stringify({status:'PASS',cases:combos.CASES.length,questions:combos.CASES.length*2,checks,scope:'pairwise fans and valid 14-tile shapes; not full scoring or circumstances'},null,2));
