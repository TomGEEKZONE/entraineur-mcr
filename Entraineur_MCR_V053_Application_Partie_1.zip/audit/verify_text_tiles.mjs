
/* V0.5.3 — audit de cohérence entre les textes de chaque défi et les tuiles affichées.
   Independent from level 5 generator. Fail on any mismatch. */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx=vm.createContext({window:{}});
vm.runInContext(fs.readFileSync(path.join(root,'challenges.js'),'utf8'),ctx);
const {CASES,instantiate,FANS,subTotal}=ctx.window.MCR_CHALLENGES;
const expectedHU={
 'draw-simple':'C8','fully-concealed-draw':'C9',
 'concealed-discard':'C6','last-wall':'C8','last-discard':'B9',
 'replacement-kong':'B5','robbing-kong':'C6',
 'double-wind':'D5','melded-hand':'D5','edge-only':'C3'
};
const expectedLinks={
 'draw-simple':['8 Caractères'],
 'fully-concealed-draw':[],
 'concealed-discard':[],
 'last-wall':[],
 'last-discard':[],
 'replacement-kong':['9 Caractères','5 Bambous'],
 'robbing-kong':['6 Caractères'],
 'double-wind':[],
 'melded-hand':['5 Cercles'],
 'edge-only':['3 Caractères','1-2 Caractères']
};
const independPoints={28:16,39:8,44:8,45:8,46:8,47:8,49:6,50:6,51:6,53:6,56:4,59:2,60:2,61:2,62:2,63:2,73:1,74:1,77:1,79:1,80:1};
const suit={B:'Bambous',C:'Caractères',D:'Cercles'};
const tileCode=(rank,suitName)=>Object.keys(suit).find(x=>suit[x]===suitName)+rank;
let assertionCount=0;
function check(condition,message){assert.ok(condition,message);assertionCount++;}
check(CASES.length===10,'10 cases expected');
check(new Set(CASES.map(c=>c.id)).size===10,'Case IDs unique');
check(Object.keys(expectedHU).length===10,'HU fixtures exhaustive');
for(const c of CASES){
 check(c.groups.length===5,`${c.id} five groups`);
 const physical=c.groups.flat().map(x=>x.replace(/!$/,''));
 const winner=c.groups.flat().filter(x=>x.endsWith('!'));
 check(winner.length===1,`${c.id} exactly one HU`);
 check(winner[0].slice(0,-1)===expectedHU[c.id],`${c.id}: wrong winning tile, expected ${expectedHU[c.id]} got ${winner[0]}`);
 for(const seed of [0,0.1,0.5,0.999]){
   const scene=instantiate(c,()=>seed);
   check(JSON.stringify(scene.groups)===JSON.stringify(c.groups),`${c.id}: generator changed tiles at seed ${seed} while texts stayed fixed`);
 }
 for(const label of expectedLinks[c.id]){
   check(c.context.includes(label),`${c.id}: the expected reference ${label} disappeared`);
 }
 const allDisplayedText=[c.context,c.ask,c.reason,c.title].join(' ');
 const mentions=[...allDisplayedText.matchAll(/\b([1-9])\s+(Caractères|Cercles|Bambous)\b/g)];
 for(const [,rank,family] of mentions){
   const code=tileCode(rank,family);
   check(physical.includes(code),`${c.id}: mentions ${rank} ${family}, but tile ${code} absent`);
 }
 // Chows, Pungs, Kongs and pair, with maximum four copies of each tile.
 const count={};
 for(const t of physical)count[t]=(count[t]||0)+1;
 check(Object.values(count).every(n=>n<=4),`${c.id}: impossible tile multiplicity`);
 const groups=c.groups.map(g=>g.map(t=>t.replace(/!$/,'')));
 const validMeld=g=>g.length===4&&g.every(t=>t===g[0]) ||
   g.length===3&&(g.every(t=>t===g[0]) ||
   /^[BCD][1-9]$/.test(g[0])&&g.every(t=>t[0]===g[0][0])&&+g[1][1]===+g[0][1]+1&&+g[2][1]===+g[0][1]+2);
 check(groups.slice(0,4).every(validMeld),`${c.id}: invalid meld`);
 check(groups[4].length===2&&groups[4][0]===groups[4][1],`${c.id}: invalid pair`);
 const kongN=groups.slice(0,4).filter(g=>g.length===4).length;
 check(physical.length===14+kongN,`${c.id}: incorrect tile count`);
 const sum=c.target.reduce((n,id)=>{
  check(independPoints[id]!==undefined,`${c.id}: unknown fan ${id}`);
  check(FANS[id].points===independPoints[id],`${c.id}: wrong fan value ${id}`);
  return n+independPoints[id];
 },0);
 check(subTotal(c)===sum,`${c.id}: incorrect subtotal`);
 // Circumstantial consistency and explicit exceptional rules.
 if(c.id==='melded-hand'){
   check(c.open.length===4&&c.win==='discard',`Melded hand not truly melded`);
   check(c.groups[4].includes('D5!'),`Melded hand HU must be D5`);
 }
 if(c.id==='robbing-kong'){
   check(c.special==='robKong'&&c.groups.some(g=>g.includes('C6!')),`Robbing kong HU mismatch`);
 }
 if(c.id==='edge-only'){
   check(c.groups[0].join(',')==='C1,C2,C3!',`Edge wait must show 1-2 -> 3`);
   check(!c.open.includes(0),`Edge wait claimed from exposed set`);
 }
 if(c.id==='replacement-kong'){
   check(c.groups.some(g=>g.length===4&&g.every(t=>t==='C9')),`The named 9 Characters Kong is absent`);
   check(c.groups.some(g=>g.includes('B5!')),`The named 5 Bamboo replacement is absent`);
 }
}
const oldSW=fs.readFileSync(path.join(root,'sw.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
check(html.includes('VERSION 0.5.3'), 'Visible version marker missing');
for(const file of ['style.css','data.js','variants.js','combos.js','challenges.js','app.js']){
 check(html.includes(file+'?v=0.5.3'),`${file} missing cache-busting version`);
}
check(oldSW.includes('mcr-trainer-v0.5.3'), 'SW version not bumped');
check(oldSW.includes("cache:'no-store'"), 'Network-first scripts strategy missing');
check(!html.includes('VERSION 0.5 ·'), 'Stale version marker found');
console.log(JSON.stringify({
 result:'PASS',testedCases:CASES.length,uniqueWinningTiles:10,
 questionTypes:CASES.length*2,sourceContextReferencesChecked:true,
 generatorKeepsTilesAndTextInSync:true,cacheUpdateGuard:true,
 checks:assertionCount,
 note:'Non-exhaustive regulatory verification remains separate'
},null,2));
