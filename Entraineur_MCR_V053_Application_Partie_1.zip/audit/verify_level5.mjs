/* Independent audit of the targeted fan values/shape/circumstances of level 5.
   This does not calculate every possible fan in each hand.
   Normative source: WMO 2006 Green Book adopted by EMA, §3.9 and fan appendix. */
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {fileURLToPath} from 'node:url';
const folder=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx=vm.createContext({window:{}});vm.runInContext(fs.readFileSync(path.join(folder,'challenges.js'),'utf8'),ctx);
const {CASES,FANS,instantiate,subTotal}=ctx.window.MCR_CHALLENGES;
const REF={28:16,39:8,44:8,45:8,46:8,47:8,49:6,50:6,51:6,53:6,56:4,59:2,60:2,61:2,62:2,63:2,73:1,74:1,77:1,79:1,80:1};
let checks=0,physical=0,contextual=0,variants=0;function ok(cond,msg){checks++;if(!cond)throw Error(msg);}
const base=t=>t.replace(/!$/,'');const suited=t=>/^[BCD][1-9]$/.test(t);const honor=t=>/^(?:WE|WS|WW|WN|DR|DG|DW)$/.test(t);
function chow(g){return g.length===3&&g.every(t=>suited(t))&&g.every(t=>t[0]===g[0][0])&&+g[1][1]===+g[0][1]+1&&+g[2][1]===+g[0][1]+2;}
function pung(g){return g.length===3&&g.every(t=>t===g[0]);}
function kong(g){return g.length===4&&g.every(t=>t===g[0]);}
function shape(c){
 const groups=c.groups.map(g=>g.map(base)),all=groups.flat(),counts={};
 ok(groups.length===5,`5 groups ${c.id}`);ok(groups.slice(0,4).every(g=>chow(g)||pung(g)||kong(g)),`not 4 valid figures ${c.id}`);ok(groups[4].length===2&&groups[4][0]===groups[4][1],`pair ${c.id}`);
 ok(all.length===14+groups.slice(0,4).filter(kong).length,`physical count ${c.id}`);
 for(const t of all){ok(suited(t)||honor(t),`unknown tile ${t}`);counts[t]=(counts[t]||0)+1;}
 ok(Object.values(counts).every(n=>n<=4),`tile repeated more than 4 ${c.id}`);
 const marked=c.groups.flat().filter(t=>t.endsWith('!'));ok(marked.length===1,`one winning tile ${c.id}`);
 ok(!c.open.includes(4)&&new Set(c.open).size===c.open.length&&c.open.every(n=>Number.isInteger(n)&&n>=0&&n<=3),`invalid open sets ${c.id}`);
 ok(!c.open.includes(c.groups.findIndex(g=>g.some(t=>t.endsWith('!'))))||c.groups[4].some(t=>t.endsWith('!'))||c.special==='kongReplacement',`HU in already exposed set ${c.id}`);
 return {groups,all,counts};
}
function chowsOf(groups){return groups.slice(0,4).filter(chow);}
function holds(id,c,groups,all){const chows=chowsOf(groups);const melds=groups.slice(0,4);const suitset=new Set(all.filter(suited).map(t=>t[0]));
 switch(id){
 case 28:return ['B','C','D'].some(s=>[1,4,7].every(n=>chows.some(g=>g[0]===s+n)));
 case 39:return [1,4,7].every(n=>chows.some(g=>+g[0][1]===n))&&new Set([1,4,7].map(n=>chows.find(g=>+g[0][1]===n)[0][0])).size===3;
 case 44:return c.win==='draw'&&c.special==='lastWall';
 case 45:return c.win==='discard'&&c.special==='lastDiscard';
 case 46:return c.win==='draw'&&c.special==='kongReplacement'&&melds.some(kong);
 case 47:return c.win==='discard'&&c.special==='robKong';
 case 49:return melds.every(g=>pung(g)||kong(g));
 case 50:return suitset.size===1&&all.some(honor);
 case 51:for(let i=0;i<chows.length;i++)for(let j=i+1;j<chows.length;j++)for(let k=j+1;k<chows.length;k++){
  let tri=[chows[i],chows[j],chows[k]],s=new Set(tri.map(g=>g[0][0])),n=tri.map(g=>+g[0][1]).sort((a,b)=>a-b);if(s.size===3&&n[1]===n[0]+1&&n[2]===n[1]+1)return true;
 }return false;
 case 53:return c.open.length===4&&c.win==='discard'&&c.groups[4].some(t=>t.endsWith('!'));
 case 56:return c.open.length===0&&c.win==='draw'&&c.special==='none';
 case 59:return melds.some(g=>(pung(g)||kong(g))&&/^D[RGW]$/.test(g[0]));
 case 60:return melds.some(g=>(pung(g)||kong(g))&&g[0]===c.prevWind);
 case 61:return melds.some(g=>(pung(g)||kong(g))&&g[0]===c.seatWind);
 case 62:return c.open.length===0&&c.win==='discard'&&c.special==='none';
 case 63:return melds.every(chow)&&groups[4].every(suited);
 case 74:return c.open.some(index=>kong(melds[index]));
 case 77:{const idx=c.groups.findIndex(g=>g.some(t=>t.endsWith('!')));if(idx<0||idx===4||c.open.includes(idx)||c.win!=='discard')return false;
  const g=groups[idx],win=c.groups[idx].find(t=>t.endsWith('!'));return chow(g)&&((g[0].endsWith('1')&&base(win)===g[2])||(g[2].endsWith('9')&&base(win)===g[0]));}
 case 80:return c.win==='draw'&&c.special==='none';
 default:throw Error('Rule not implemented '+id);
 }
}
function checkCase(c){const {groups,all}=shape(c);physical++;
 for(const id of c.target){ok(REF[id]!==undefined,`unverified fan ${id}`);ok(FANS[id].points===REF[id],`wrong points ${id}`);ok(holds(id,c,groups,all),`fan ${id} false in ${c.id}`);}
 ok(subTotal(c)===c.target.reduce((n,id)=>n+REF[id],0),`subtotal ${c.id}`);
 ok(c.choices.length===4&&new Set(c.choices).size===4&&c.choices.includes(c.correct),`MCQ ${c.id}`);
 for(const id of c.excluded||[]){ok(REF[id]!==undefined,`unknown excluded ${id}`);}
 if(c.excluded?.includes(80))ok(c.special==='lastWall'||c.special==='kongReplacement'||c.target.includes(56),`unsafe selfdraw exclusion ${c.id}`);
 if(c.excluded?.includes(79))ok(c.target.includes(53),`unsafe single wait exclusion ${c.id}`);
 if(c.excluded?.includes(73))ok(c.seatWind===c.prevWind&&c.target.includes(61)&&c.target.includes(60),`unsafe wind exclusion ${c.id}`);
 if(c.special!=='none')contextual++;
}
ok(CASES.length===10,'Expected 10 scenarios');let used=new Set();
for(const c of CASES){ok(!used.has(c.id),'duplicate '+c.id);used.add(c.id);
 for(let i=0;i<40;i++){const scene=i===0?c:instantiate(c);checkCase(scene);variants++;}
}
// Negatives: run the same independently encoded predicate on near-miss scenarios.
const one=id=>CASES.find(c=>c.id===id);
function forbidden(id,edit,fan){const clone=structuredClone(one(id));edit(clone);const g=clone.groups.map(s=>s.map(base));ok(!holds(fan,clone,g,g.flat()),`counterexample accepted ${id} ${fan}`);}
forbidden('last-wall',c=>{c.special='none'},44);
forbidden('last-discard',c=>{c.win='draw'},45);
forbidden('replacement-kong',c=>{c.special='none'},46);
forbidden('robbing-kong',c=>{c.special='none'},47);
forbidden('fully-concealed-draw',c=>{c.open=[1]},56);
forbidden('concealed-discard',c=>{c.open=[1]},62);
forbidden('double-wind',c=>{c.seatWind='WE'},61);
forbidden('melded-hand',c=>{c.open=[1,2,3]},53);
forbidden('edge-only',c=>{c.groups[0]=['C1','C2','C2!']},77);
forbidden('draw-simple',c=>{c.special='lastWall'},80);
forbidden('replacement-kong',c=>{c.groups[3]=['C9','C9','C9']},74);
console.log(JSON.stringify({status:'PASS',cases:CASES.length,questions:CASES.length*2,scenariosValidated:variants,checks,physical,contextual,nearMisses:11,scope:'Ten complete illustrated hands, targeted fans and context metadata, not exhaustive scoring'},null,2));
