#!/usr/bin/env node
/*
 * Entraîneur MCR — audit reproductible des exemples pédagogiques.
 * Usage: node audit/verify.mjs [chemin-vers-data.js] [--json rapport.json] [--strict]
 * Zéro dépendance npm. Il lit le vrai data.js de l'application.
 * Les règles de contrôle sont une transcription indépendante de cas de référence :
 * - WMO / EMA 2006 Green Book, annexe 81 fans : https://mahjong-europe.org/portal/images/docs/mcr_ENa5.pdf
 * - FFMJ, Guide des combinaisons mai 2013 : https://www.ffmahjong.fr/FFMJ-site/documents/GuideFFMJ_MCR.pdf
 * Ce programme ne remplace pas l'arbitrage MCR et ne valide pas un texte par IA.
 */
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import vm from 'node:vm';

const args = process.argv.slice(2);
let dataArg = args.find(v => !v.startsWith('--')) ?? path.join(path.dirname(new URL(import.meta.url).pathname),'..','data.js');
const strict = args.includes('--strict');
const outIndex = args.indexOf('--json');
const outFile = outIndex >= 0 ? args[outIndex+1] : null;
// Avoid interpreting the JSON output filename as data.js.
if (dataArg === outFile) dataArg = path.join(path.dirname(new URL(import.meta.url).pathname),'..','data.js');
const dataPath = path.resolve(dataArg);
const appRoot = path.dirname(dataPath);
const context = vm.createContext({window:{}});
vm.runInContext(fs.readFileSync(dataPath,'utf8'), context, {filename:dataPath, timeout:2000});
const fans = JSON.parse(JSON.stringify(context.window.MCR_DATA));
const levels = JSON.parse(JSON.stringify(context.window.MCR_LEVELS));
const ASSET_HASHES = JSON.parse(fs.readFileSync(path.join(path.dirname(new URL(import.meta.url).pathname),'assets-sha256.json'),'utf8'));
const TEXT_HASHES = JSON.parse(fs.readFileSync(path.join(path.dirname(new URL(import.meta.url).pathname),'textes-reference.json'),'utf8'));
const CANONICAL_NAMES = {
  28:'Pure Straight',39:'Mixed Straight',49:'All Pungs',50:'Half Flush',51:'Mixed Shifted Chows',52:'All Types',
  59:'Dragon Pung',62:'Concealed Hand',63:'All Chows',69:'Pure Double Chow',70:'Mixed Double Chow',
  71:'Short Straight',72:'Two Terminal Chows',73:'Pung of Terminals or Honors',75:'One Voided Suit',
  76:'No Honors',77:'Edge Wait',78:'Closed Wait',79:'Single Wait',80:'Self-Drawn'
};
const SOURCE_WMO = 'https://mahjong-europe.org/portal/images/docs/mcr_ENa5.pdf';
const SOURCE_FFMJ = 'https://www.ffmahjong.fr/FFMJ-site/documents/GuideFFMJ_MCR.pdf';
// These values / conditions are transcribed from the official scoring table,
// separately from data.js. Changes here require source review.
const RULES = {
  28:{points:16,key:'pure-straight'},39:{points:8,key:'mixed-straight'},
  49:{points:6,key:'all-pungs'},50:{points:6,key:'half-flush'},51:{points:6,key:'mixed-shifted-chows'},
  52:{points:6,key:'all-types'},59:{points:2,key:'dragon-pung'},62:{points:2,key:'concealed-hand',needs:['melds_exposure','win_discard']},
  63:{points:2,key:'all-chows'},69:{points:1,key:'pure-double-chow'},70:{points:1,key:'mixed-double-chow'},
  71:{points:1,key:'short-straight'},72:{points:1,key:'two-terminal-chows'},73:{points:1,key:'pung-of-terminals-or-winds',needs:['seat_wind','prevalent_wind']},
  75:{points:1,key:'voided-suit'},76:{points:1,key:'no-honors'},77:{points:1,key:'edge-wait',needs:['unique_wait']},
  78:{points:1,key:'closed-wait',needs:['unique_wait']},79:{points:1,key:'single-wait',needs:['unique_wait']},
  80:{points:1,key:'self-drawn',needs:['win_self_draw']}
};
function norm(code) { return code.replace(/!$/,''); }
function isSuit(code) {return /^[BCD][1-9]$/.test(norm(code));}
function isHonor(code){return /^(W[ESWN]|D[RGW])$/.test(norm(code));}
function isWind(code){return /^W[ESWN]$/.test(norm(code));}
function isDragon(code){return /^D[RGW]$/.test(norm(code));}
function gnorm(f){return f.groups.map(g=>g.map(norm));}
function tileGroups(f){return gnorm(f);}
function tiles(f){return tileGroups(f).flat();}
function isChow(g){if(g.length!==3 || !g.every(isSuit))return false;const s=g[0][0];if(!g.every(t=>t[0]===s))return false;const vals=g.map(t=>Number(t[1])).sort((a,b)=>a-b);return vals[1]===vals[0]+1 && vals[2]===vals[1]+1;}
function chowSig(g){ if(!isChow(g))return null;return {suit:g[0][0],start:Math.min(...g.map(t=>+t[1]))}; }
function pung(g){return g.length===3 && g.every(t=>t===g[0]);}
function pair(g){return g.length===2 && g[0]===g[1];}
function twoChows(f) {const gs=tileGroups(f);return gs.length===2 && gs.every(isChow);}
function checkFan(f){const gs=tileGroups(f),tt=tiles(f),ch=gs.map(chowSig);switch(f.id){
 case 28:return gs.length===3 && gs.every(isChow) && new Set(ch.map(x=>x.suit)).size===1 && ch.map(x=>x.start).sort((a,b)=>a-b).join(',')==='1,4,7';
 case 39:return gs.length===3 && gs.every(isChow) && new Set(ch.map(x=>x.suit)).size===3 && ch.map(x=>x.start).sort((a,b)=>a-b).join(',')==='1,4,7';
 case 49:return gs.length===5 && gs.filter(pung).length===4 && gs.filter(pair).length===1;
 case 50:{const ss=new Set(tt.filter(isSuit).map(t=>t[0]));return ss.size===1&&tt.some(isHonor);}
 case 51:return gs.length===3 && gs.every(isChow) && new Set(ch.map(x=>x.suit)).size===3 && ((a)=>a[1]-a[0]===1&&a[2]-a[1]===1)(ch.map(x=>x.start).sort((a,b)=>a-b));
 case 52:{const cat=new Set(tt.map(t=>isSuit(t)?t[0]:isWind(t)?'wind':isDragon(t)?'dragon':'other'));return ['B','C','D','wind','dragon'].every(k=>cat.has(k));}
 case 59:return gs.some(g=>pung(g)&&g.every(isDragon));
 case 62:return gs.length===5&&gs.filter(g=>isChow(g)||pung(g)).length===4&&gs.filter(pair).length===1;
 case 63:return gs.length===5&&gs.filter(isChow).length===4&&gs.filter(g=>pair(g)&&isSuit(g[0])).length===1;
 case 69:return twoChows(f)&&ch[0].suit===ch[1].suit&&ch[0].start===ch[1].start;
 case 70:return twoChows(f)&&ch[0].suit!==ch[1].suit&&ch[0].start===ch[1].start;
 case 71:return twoChows(f)&&ch[0].suit===ch[1].suit&&Math.abs(ch[0].start-ch[1].start)===3;
 case 72:return twoChows(f)&&ch[0].suit===ch[1].suit&&ch.map(x=>x.start).sort((a,b)=>a-b).join(',')==='1,7';
 case 73:return gs.some(g=>pung(g) && (isWind(g[0])||(isSuit(g[0])&&['1','9'].includes(g[0][1]))));
 case 75:return new Set(tt.filter(isSuit).map(t=>t[0])).size<=2 && tt.some(isSuit);
 case 76:return !tt.some(isHonor) && tt.some(isSuit) && !(gs.length===5 && gs.filter(isChow).length===4 && gs.some(pair)); // Ne pas enseigner No Honors comme point cumulable lorsque All Chows l'implique.
 case 77:return gs.length===1&&isChow(gs[0])&&f.groups.flat().filter(t=>t.endsWith('!')).length===1 && ((ch[0].start===1 && f.groups[0].includes(gs[0][0][0]+'3!')) || (ch[0].start===7 && f.groups[0].includes(gs[0][0][0]+'7!')));
 case 78:return gs.length===1&&isChow(gs[0])&&f.groups.flat().filter(t=>t.endsWith('!')).length===1&&f.groups[0].includes(gs[0][0][0]+(ch[0].start+1)+'!');
 case 79:return gs.length===1&&pair(gs[0])&&f.groups[0].filter(t=>t.endsWith('!')).length===1;
 case 80:return gs.length===1&&f.groups.flat().filter(t=>t.endsWith('!')).length===1;
 default:return false;
}}
const errors=[], warnings=[], passed=[], perFan=[];
function err(code,message,fan){errors.push({code,fan,message});}
function warn(code,message,fan){warnings.push({code,fan,message});}
const ids = fans.map(f=>f.id);const seen = new Set();
for(const f of fans){
 const issues=[];const rule=RULES[f.id];
 if(seen.has(f.id)){err('DUPLICATE_ID',`Fan n° ${f.id} dupliqué`,f.id);issues.push('DUPLICATE_ID');}
 seen.add(f.id);
 if(!rule){err('UNKNOWN_FAN',`Fan n° ${f.id} hors référentiel`,f.id);issues.push('UNKNOWN_FAN');continue;}
 const contentHash=crypto.createHash('sha256').update(['fr','en','prompt','definition','note'].map(k=>String(f[k]??'').trim()).join('\n')).digest('hex');
 if(TEXT_HASHES[f.id]!==contentHash)warn('TEXT_CHANGED_REVIEW_REQUIRED',`Le texte du fan n° ${f.id} diffère de la version de référence et requiert une nouvelle relecture.`,f.id);
 if(f.en!==CANONICAL_NAMES[f.id]){err('WRONG_NAME',`Fan n° ${f.id} : nom anglais « ${f.en} » au lieu de « ${CANONICAL_NAMES[f.id]} »`,f.id);issues.push('WRONG_NAME');}
 if(f.points!==rule.points){err('WRONG_POINTS',`Fan n° ${f.id} : ${f.points} pts au lieu de ${rule.points}`,f.id);issues.push('WRONG_POINTS');}
 if(![1,2,3].includes(f.level)){err('INVALID_LEVEL',`Niveau ${f.level} non jouable`,f.id);issues.push('INVALID_LEVEL');}
 if(!['main','fragment','situation'].includes(f.kind)){err('INVALID_KIND',`Type ${f.kind}`,f.id);issues.push('INVALID_KIND');}
 for(const field of ['fr','en','prompt','definition','note'])if(!String(f[field]??'').trim()){err('MISSING_TEXT',`Champ ${field} vide`,f.id);issues.push('MISSING_TEXT');}
 if(!Array.isArray(f.groups)||!f.groups.length){err('MISSING_TILES','Aucun groupe de tuiles',f.id);issues.push('MISSING_TILES');continue;}
 for(const g of f.groups)if(!Array.isArray(g)||!g.length){err('EMPTY_GROUP','Groupe vide',f.id);issues.push('EMPTY_GROUP');}
 const allCodes=f.groups.flat(),clean=allCodes.map(norm),count={};
 for(const code of clean){count[code]=(count[code]||0)+1;if(!isSuit(code)&&!isHonor(code)){err('INVALID_TILE',`Identifiant tuile non reconnu : ${code}`,f.id);issues.push('INVALID_TILE');}
 const suitPaths={B:'bambous',C:'caracteres',D:'cercles'}, honors={WE:'vents/est',WS:'vents/sud',WW:'vents/ouest',WN:'vents/nord',DR:'dragons/rouge',DG:'dragons/vert',DW:'dragons/blanc'};
 const img=isSuit(code)?path.join(appRoot,'assets',suitPaths[code[0]],code[1]+'.png'):honors[code]?path.join(appRoot,'assets',honors[code]+'.png'):null;
 if(img&&!fs.existsSync(img)){err('MISSING_PNG',`Image absente pour ${code}`,f.id);issues.push('MISSING_PNG');}
 }
 for(const [code,n] of Object.entries(count))if(n>4){err('TOO_MANY_COPIES',`${n} exemplaires de ${code} (maximum physique 4)`,f.id);issues.push('TOO_MANY_COPIES');}
 if(f.kind==='main'&&clean.length!==14){err('WRONG_HAND_SIZE',`Main de ${clean.length} tuiles au lieu de 14`,f.id);issues.push('WRONG_HAND_SIZE');}
 if(allCodes.filter(t=>t.endsWith('!')).length>1){err('MULTIPLE_HU','Plusieurs tuiles gagnantes marquées',f.id);issues.push('MULTIPLE_HU');}
 let shape=false;try{shape=checkFan(f);}catch(e){err('CHECK_FAILURE',String(e.message),f.id);}
 if(!shape){err('RULE_MISMATCH',`L'exemple n° ${f.id} ne respecte pas la structure attendue pour « ${f.fr} ».`,f.id);issues.push('RULE_MISMATCH');}
 if(f.id===51&&!/décalage d.un rang|décalés chacun d.un numéro|consécutives/i.test(f.definition+' '+f.prompt)){err('SHIFT51_TEXT','Le texte ne précise plus le décalage unitaire',f.id);issues.push('SHIFT51_TEXT');}
 if(rule.needs){warn('MISSING_INDEPENDENT_CONTEXT',`Fan n° ${f.id} : vérification complète impossible avec les tuiles seules (${rule.needs.join(', ')}).`,f.id);issues.push('CONTEXT_TO_VERIFY');}
 perFan.push({id:f.id,name:f.fr,level:f.level,points:f.points,status:issues.some(k=>k!=='CONTEXT_TO_VERIFY')?'ERREUR':rule.needs?'CONDITIONNEL':'CONFORME_STRUCTURE',issues,source:SOURCE_WMO});
 }
// Vérifier également les variantes générées pour chaque exercice :
// pas de figure inventée par permutation, pas de cinquième exemplaire, HU unique.
const variantFile = path.join(appRoot,'variants.js');
let variantsVerified=0;
if (!fs.existsSync(variantFile))err('MISSING_VARIANTS','Fichier de variation absent',null);
else {
 vm.runInContext(fs.readFileSync(variantFile,'utf8'),context,{filename:variantFile,timeout:3000});
 const produce=context.window.MCR_VARIANTS?.generate;
 if(typeof produce!=='function')err('BAD_VARIANT_API','Générateur absent ou invalide',null);
 else for(const f of fans){
   let previous='';
   for(let trial=0;trial<120;trial++){
      let v=produce(f,previous);previous=v.variantKey;
      let codeCounts={}, marks=0;
      for(const t of v.groups.flat()){
        const id=norm(t);codeCounts[id]=(codeCounts[id]||0)+1;
        if(t.endsWith('!'))marks++;
      }
      if(!checkFan(v) || marks>1 || Object.values(codeCounts).some(n=>n>4) || (f.kind==='main' && v.groups.flat().length!==14)){
        err('INVALID_VARIANT',`Fan ${f.id}, tirage ${trial}: variante invalide ${JSON.stringify(v.groups)}`,f.id);
        break;
      }
      variantsVerified++;
   }
 }
}
// Tests négatifs indépendants : chaque mutation ci-dessous doit être rejetée.
function mutant(id,groups){let original=fans.find(f=>f.id===id);if(!original)throw Error('Fan manquant '+id);return {...original,groups};}
const counterExamples = [
 {id:51,label:'Décalage de deux au lieu de un',groups:[['C1','C2','C3'],['D3','D4','D5'],['B5','B6','B7']]},
 {id:51,label:'Tous les chows dans une famille',groups:[['C1','C2','C3'],['C2','C3','C4'],['C3','C4','C5']]},
 {id:70,label:'Double chow pur donné comme mixed',groups:[['B3','B4','B5'],['B3','B4','B5']]},
 {id:69,label:'Deux familles dans double chow pur',groups:[['B3','B4','B5'],['D3','D4','D5']]},
 {id:71,label:'Chows superposés au lieu de suite continue',groups:[['B1','B2','B3'],['B2','B3','B4']]},
 {id:72,label:'Deux extrémités dans deux familles',groups:[['B1','B2','B3'],['D7','D8','D9']]},
 {id:59,label:'Pung de vent pris pour dragon',groups:[['WE','WE','WE']]},
 {id:73,label:'Pung de 5 ne vaut pas terminal',groups:[['C5','C5','C5']]},
 {id:76,label:'Main avec honneur',groups:[['WE','WE','WE']]},
 {id:76,label:'Pas d’Honneur déjà inclus dans Tout Chow',groups:[['C1','C2','C3'],['D3','D4','D5'],['B4','B5','B6'],['D7','D8','D9'],['C5','C5']]},
 {id:75,label:'Les trois familles présentes',groups:[['B1'],['C1'],['D1']]},
 {id:50,label:'Deux familles numérotées',groups:[['C1','C2','C3'],['B4','B5','B6'],['WE','WE']]},
 {id:52,label:'Sans dragon',groups:[['C1','C2','C3'],['B4','B5','B6'],['D6','D7','D8'],['WS','WS','WS'],['B2','B2']]},
 {id:49,label:'Chow à la place du quatrième pung',groups:[['C2','C2','C2'],['D5','D5','D5'],['B8','B8','B8'],['C1','C2','C3'],['WE','WE']]},
 {id:63,label:'Pung à la place du dernier chow',groups:[['C1','C2','C3'],['D3','D4','D5'],['B4','B5','B6'],['D7','D7','D7'],['C5','C5']]},
 {id:39,label:'Même famille partout (pure)',groups:[['C1','C2','C3'],['C4','C5','C6'],['C7','C8','C9']]},
 {id:28,label:'Trois familles (mixed)',groups:[['C1','C2','C3'],['D4','D5','D6'],['B7','B8','B9']]},
 {id:77,label:'Attente incorrecte sur 2 de 123',groups:[['C1','C2!','C3']]},
 {id:78,label:'Attente incorrecte sur 3 de 123',groups:[['C1','C2','C3!']]},
 {id:79,label:'Deux tuiles distinctes ne forment pas une paire',groups:[['C4','C5!']]}
];
let rejected=0;
for(const case0 of counterExamples){if(!checkFan(mutant(case0.id,case0.groups))){rejected++;}else{err('BAD_COUNTEREXAMPLE',`Le vérificateur accepte à tort : ${case0.id} — ${case0.label}`,case0.id);}}
// Vérifier l'intégrité de TOUS les PNG livrés, même ceux qui ne figurent pas dans les 20 leçons.
for(const [relative,sha] of Object.entries(ASSET_HASHES)){
 const img=path.join(appRoot,'assets',relative);
 if(!fs.existsSync(img)){err('MISSING_BASE_IMAGE',`Illustration absente : ${relative}`,null);continue;}
 const actual=crypto.createHash('sha256').update(fs.readFileSync(img)).digest('hex');
 if(actual!==sha)err('CHANGED_TILE_IMAGE',`Illustration modifiée : ${relative}`,null);
}
const usedAssets = new Set(fans.flatMap(f=>f.groups.flat().map(norm)));
const expectedIds = Object.keys(RULES).map(Number);
for(const id of expectedIds)if(!seen.has(id))err('MISSING_FAN',`Fan ${id} absent`,id);
const observedLevels = Object.fromEntries(levels.filter(l=>!l.planned).map(l=>[l.id,fans.filter(f=>f.level===l.id).length]));
if(Object.values(observedLevels).reduce((a,b)=>a+b,0)!==20)err('WRONG_FAN_COUNT',`Nombre de fans total : ${fans.length}`);
const result={
 audited_at:new Date().toISOString(),app_file:dataPath,reference:'WMO/EMA Green Book 2006 + Guide FFMJ mai 2013',
 sources:[SOURCE_WMO,SOURCE_FFMJ],
 scope:'Audit structurel et de données seulement. Le calcul intégral des fans, la validité des mains et les règles de cumul demandent des tests supplémentaires.',
 totals:{fans:fans.length,levels:observedLevels,structure_ok:perFan.filter(f=>f.status==='CONFORME_STRUCTURE').length,conditional:perFan.filter(f=>f.status==='CONDITIONNEL').length,errors:errors.length,warnings:warnings.length,negative_tests_passed:rejected,negative_tests_total:counterExamples.length,assets_referenced:usedAssets.size,assets_verified:Object.keys(ASSET_HASHES).length,variants_verified:variantsVerified},
 fan_results:perFan,errors,warnings,counterexample_results:counterExamples.map(c=>({id:c.id,label:c.label,rejected:!checkFan(mutant(c.id,c.groups))}))
};
if(outFile)fs.writeFileSync(path.resolve(outFile),JSON.stringify(result,null,2)+'\n');
console.log('AUDIT MCR · 20 FANS');console.log(`${fans.length} fans | ${result.totals.structure_ok} conformes en structure | ${result.totals.conditional} conditionnels | ${errors.length} erreurs | ${warnings.length} alertes`);
console.log(`Contre-exemples rejetés : ${rejected}/${counterExamples.length} | Variantes contrôlées : ${variantsVerified}`);
for(const e of errors)console.log('ERREUR',e.fan,e.message);
for(const w of warnings)console.log('À CONFIRMER',w.fan,w.message);
process.exitCode=errors.length || (strict && warnings.length) ? 1 : 0;
