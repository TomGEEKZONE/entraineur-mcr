/* Entraîneur MCR V0.5.3 — Mise à jour fiable, sans toucher au localStorage */
const CACHE='mcr-trainer-v0.5.3-20261116';
const PRECACHE=["./", "./index.html", "./style.css?v=0.5.3", "./data.js?v=0.5.3", "./variants.js?v=0.5.3", "./combos.js?v=0.5.3", "./challenges.js?v=0.5.3", "./app.js?v=0.5.3", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png", "./assets/bambous/1.png", "./assets/bambous/2.png", "./assets/bambous/3.png", "./assets/bambous/4.png", "./assets/bambous/5.png", "./assets/bambous/6.png", "./assets/bambous/7.png", "./assets/bambous/8.png", "./assets/bambous/9.png", "./assets/caracteres/1.png", "./assets/caracteres/2.png", "./assets/caracteres/3.png", "./assets/caracteres/4.png", "./assets/caracteres/5.png", "./assets/caracteres/6.png", "./assets/caracteres/7.png", "./assets/caracteres/8.png", "./assets/caracteres/9.png", "./assets/cercles/1.png", "./assets/cercles/2.png", "./assets/cercles/3.png", "./assets/cercles/4.png", "./assets/cercles/5.png", "./assets/cercles/6.png", "./assets/cercles/7.png", "./assets/cercles/8.png", "./assets/cercles/9.png", "./assets/dragons/blanc.png", "./assets/dragons/rouge.png", "./assets/dragons/vert.png", "./assets/fleurs_saisons/automne.png", "./assets/fleurs_saisons/bambou.png", "./assets/fleurs_saisons/chrysantheme.png", "./assets/fleurs_saisons/ete.png", "./assets/fleurs_saisons/hiver.png", "./assets/fleurs_saisons/orchidee.png", "./assets/fleurs_saisons/printemps.png", "./assets/fleurs_saisons/prunier.png", "./assets/vents/est.png", "./assets/vents/nord.png", "./assets/vents/ouest.png", "./assets/vents/sud.png", "./ressources/La_Baie_de_Jade_Memo_01_Tuiles_et_Figures.pdf", "./ressources/La_Baie_de_Jade_Memo_02_Combinaisons.pdf", "./ressources/Fiche_MCR_81_combinaisons.pdf"];
self.addEventListener('install',event=>{
 event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(PRECACHE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
 event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('mcr-trainer-') && key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET')return;
 const url=new URL(event.request.url);
 if(url.origin!==self.location.origin)return;
 const sourceFirst=event.request.mode==='navigate'||/\.(?:js|css)$/.test(url.pathname);
 event.respondWith((async()=>{
   const cache=await caches.open(CACHE);
   if(sourceFirst){
      try{
         const response=await fetch(event.request,{cache:'no-store'});
         if(response.ok)await cache.put(event.request,response.clone());
         return response;
      }catch(error){
         const saved=await cache.match(event.request);
         if(saved)return saved;
         throw error;
      }
   }
   const saved=await cache.match(event.request);
   if(saved)return saved;
   const response=await fetch(event.request);
   if(response.ok)await cache.put(event.request,response.clone());
   return response;
 })());
});
