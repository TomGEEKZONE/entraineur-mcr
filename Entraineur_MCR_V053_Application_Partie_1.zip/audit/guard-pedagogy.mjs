#!/usr/bin/env node
/* Garde-fous pédagogiques V0.3 : vérifications indépendantes des contenus et de l'interface.
 * Ces tests ne certifient PAS toutes les règles de cumul du Mahjong MCR.
 * Règle référente : EMA/WMO Green Book 2006, fan 51, 59, 63, 73, 76, 77-79,
 * https://mahjong-europe.org/portal/images/docs/mcr_ENa5.pdf
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const appRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ctx=vm.createContext({window:{}});
vm.runInContext(fs.readFileSync(path.join(appRoot,'data.js'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(appRoot,'variants.js'),'utf8'),ctx);
const F=JSON.parse(JSON.stringify(ctx.window.MCR_DATA));
const byId=Object.fromEntries(F.map(f=>[f.id,f]));
const app=fs.readFileSync(path.join(appRoot,'app.js'),'utf8');
const sw=fs.readFileSync(path.join(appRoot,'sw.js'),'utf8');
let tests=0;const failed=[];
function check(ok,label){tests++;if(!ok)failed.push(label)}
const isChow=g=>g.length===3&&g.every(x=>/^[BCD][1-9]$/.test(x))&&new Set(g.map(x=>x[0])).size===1&&[0,1,2].every((x,i)=>+g.map(t=>t[1]).sort((a,b)=>a-b)[i]===+g.map(t=>t[1]).sort((a,b)=>a-b)[0]+i);
const isPair=g=>g.length===2&&g[0]===g[1];
const isPung=g=>g.length===3&&new Set(g).size===1;
function allChows(groups){return groups.filter(isChow).length===4&&groups.some(isPair)}
check(F.length===20 && new Set(F.map(f=>f.id)).size===20,'20 identifiants de fans distincts');
check(!allChows(byId[76].groups),'La fiche Pas d’Honneur ne doit plus enseigner un bonus inclus dans Tout Chow');
for(let i=0;i<150;i++){
 const g=ctx.window.MCR_VARIANTS.generate(byId[76],'').groups;
 check(!allChows(g),'Pas d’Honneur variante '+i+' ne doit pas présenter Tout Chow');
}
check(byId[63].note.includes('Pas d’Honneur'),'La fiche Tout Chow doit signaler l’exclusion de Pas d’Honneur');
check(byId[73].groups.length===2&&byId[73].connectors?.[0]==='ou','Pung 73 : 9 Caractères OU vent Est');
check(byId[73].groups[0].join()==='C9,C9,C9','Exemple de pung de 9 Caractères');
check(byId[73].groups[1].join()==='WE,WE,WE','Exemple de pung de Vent d’Est');
check(/ni le Vent du joueur ni le Vent dominant/.test(byId[73].note),'Vent Est non déterminant pour un seul point');
check(/seat_wind.+prevalent_wind/.test(fs.readFileSync(path.join(appRoot,'audit/verify.mjs'),'utf8')),'Audit : contexte du vent requis');
for(const id of [77,78,79]){
 check(/seule|unique|seul/.test(byId[id].note),'Précision attente unique du fan '+id);
 for(let i=0;i<40;i++){
  const v=ctx.window.MCR_VARIANTS.generate(byId[id],'');
  check(/seule|unique|seul/.test(v.prompt),'Le prompt contextualise l’attente unique : '+id+'/'+i);
 }
}
check(/valeur du fan, pas total de la main/.test(app),'La correction rappelle que les points du fan ne sont pas le total');
check(/Sauvegarde|STORAGE_KEY='mcr-trainer-v0\.1'/.test(app)&&/STORAGE_KEY='mcr-trainer-v0\.1'/.test(app),'La clé de sauvegarde est inchangée');
check(/mcr-trainer-v0\.5/.test(sw),'Cache du service worker renouvelé pour éviter les anciens fichiers');
const demoMatch=app.match(/function winningHandDemo\(\)\{[\s\S]*?const sets=(\[[\s\S]*?\]);/);
check(!!demoMatch,'La démonstration contient un jeu de cinq blocs');
if(demoMatch){
 const sets=vm.runInNewContext('('+demoMatch[1]+')');
 const groups=sets.map(s=>s.tiles);
 const tiles=groups.flat();
 check(groups.length===5 && groups.map(g=>g.length).join()==='3,3,3,3,2','La main possède 4 figures et une paire');
 check(groups.slice(0,3).every(isChow),'Les trois premiers blocs sont des chows');
 check(groups[3].join()==='DR,DR,DR' && isPair(groups[4]),'Un pung de dragon et une paire');
 const starts=groups.slice(0,3).map(g=>Math.min(...g.map(t=>+t[1]))).sort((a,b)=>a-b);
 check(starts.join()==='1,2,3' && new Set(groups.slice(0,3).map(g=>g[0][0])).size===3,'Trois Chows Superposés : 6 points');
 check(tiles.length===14 && Object.values(tiles.reduce((o,t)=>(o[t]=(o[t]||0)+1,o),{})).every(n=>n<=4),'14 tuiles, sans cinquième exemplaire');
 check(/8 points minimum/.test(app),'6 + 2 atteint le seuil minimal de huit points');
}
console.log(`Contrôles pédagogiques : ${tests-failed.length}/${tests} réussis`);
for(const f of failed)console.error('ERREUR : '+f);
process.exitCode=failed.length?1:0;
