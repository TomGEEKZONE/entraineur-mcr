/* Entraîneur MCR · V0.5 · Défis avancés ciblés et circonstances déclarées.
   Référence normative: WMO/EMA 2006 Green Book, annexe 1 et §3.9.
   Les sous-totaux ne sont PAS des décomptes exhaustifs. */
(function(root){
'use strict';
const S={
  28:{name:'Grande Suite Pure',points:16},39:{name:'Grande Suite',points:8},
  44:{name:'Dernière Tuile Tirée',points:8},45:{name:'Dernière Tuile Jetée',points:8},
  46:{name:'Finir sur Kong',points:8},47:{name:'Voler le Kong',points:8},
  49:{name:'Tout Pung',points:6},50:{name:'Semi-Pure',points:6},51:{name:'Trois Chows Superposés',points:6},
  53:{name:'Tout Exposé',points:6},56:{name:'Tout Caché Tiré',points:4},
  59:{name:'Pung de Dragon',points:2},60:{name:'Vent dominant',points:2},61:{name:'Vent du joueur',points:2},
  62:{name:'Tout Caché Donné',points:2},63:{name:'Tout Chow',points:2},
  73:{name:'Pung de Vent ou d’Extrémité',points:1},74:{name:'Kong exposé',points:1},77:{name:'Finir d’un Côté',points:1},79:{name:'Finir sur la Paire',points:1},
  80:{name:'Tirer soi-même',points:1}
};
const BASE_SHIFTED=[['C1','C2','C3'],['D2','D3','D4'],['B3','B4','B5'],['C6','C7','C8'],['D5','D5']];
const BASE_MIXED=[['C1','C2','C3'],['D4','D5','D6'],['B7','B8','B9'],['C4','C5','C6'],['D2','D2']];
const CASES=[
 {id:'draw-simple',title:'La pioche ordinaire',groups:[['C1','C2','C3'],['D2','D3','D4'],['B3','B4','B5'],['C6','C7','C8!'],['D5','D5']],open:[1],win:'draw',special:'none',target:[51,63,80],
  context:'Un Chow est déjà exposé. Le joueur pioche lui-même le 8 Caractères et termine sa main. Il ne s’agit ni de la dernière tuile du mur ni d’un remplacement.',
  ask:'Quel fan de victoire complète les fans de structure ?',correct:'Tirer soi-même',choices:['Tirer soi-même','Tout Caché Tiré','Dernière Tuile Tirée','Finir sur Kong'],
  reason:'La tuile gagnante vient d’une pioche ordinaire : Tirer soi-même rapporte 1 point. Un Chow exposé exclut Tout Caché Tiré. Le sous-total ciblé associe 6 + 2 + 1.'},
 {id:'fully-concealed-draw',title:'Tout caché, victoire sur pioche',groups:[['C1','C2','C3'],['C4','C5','C6'],['C7','C8','C9!'],['D2','D3','D4'],['D5','D5']],open:[],win:'draw',special:'none',target:[28,63,56],excluded:[80],
  context:'Aucune figure n’a été déclarée : toute la main est cachée, et la tuile gagnante est piochée par le joueur.',
  ask:'Quel fan de circonstance de 4 points s’applique ?',correct:'Tout Caché Tiré',choices:['Tout Caché Tiré','Tirer soi-même','Tout Caché Donné','Finir sur Kong'],
  reason:'Tout Caché Tiré vaut 4 points et comprend déjà la victoire sur pioche : on n’ajoute pas Tirer soi-même (1 point). Sous-total ciblé : 16 + 2 + 4.'},
 {id:'concealed-discard',title:'Main cachée, victoire sur défausse',groups:[['C1','C2','C3'],['D4','D5','D6'],['B7','B8','B9'],['C4','C5','C6!'],['D2','D2']],open:[],win:'discard',special:'none',target:[39,63,62],
  context:'Aucune figure n’a été déclarée. Le joueur termine sa main sur une tuile défaussée par un adversaire.',
  ask:'Quel fan décrit cette victoire sans figure exposée ?',correct:'Tout Caché Donné',choices:['Tout Caché Donné','Tout Caché Tiré','Tirer soi-même','Tout Exposé'],
  reason:'Tout Caché Donné vaut 2 points : la main est restée cachée et la victoire vient d’une défausse. Sous-total ciblé : 8 + 2 + 2.'},
 {id:'last-wall',title:'La dernière tuile du mur',groups:[['C1','C2','C3'],['D2','D3','D4'],['B3','B4','B5'],['C6','C7','C8!'],['D5','D5']],open:[1],win:'draw',special:'lastWall',target:[51,63,44],excluded:[80],
  context:'Un Chow est exposé. Le joueur gagne en piochant la toute dernière tuile du mur (pas une tuile de remplacement).',
  ask:'Quel fan spécial s’applique à cette pioche ?',correct:'Dernière Tuile Tirée',choices:['Dernière Tuile Tirée','Tirer soi-même','Dernière Tuile Jetée','Finir sur Kong'],
  reason:'Dernière Tuile Tirée vaut 8 points ; Tirer soi-même (1 point) ne s’ajoute pas. Sous-total ciblé : 6 + 2 + 8.'},
 {id:'last-discard',title:'La dernière défausse',groups:[['B1','B2','B3'],['B4','B5','B6'],['B7','B8','B9!'],['DG','DG','DG'],['B5','B5']],open:[0],win:'discard',special:'lastDiscard',target:[50,59,45],
  context:'Un Chow est déjà exposé. Le joueur gagne sur la dernière défausse de la partie, produite après la dernière tuile du mur.',
  ask:'Quel fan récompense cette dernière défausse ?',correct:'Dernière Tuile Jetée',choices:['Dernière Tuile Jetée','Dernière Tuile Tirée','Voler le Kong','Tirer soi-même'],
  reason:'Dernière Tuile Jetée vaut 8 points : il s’agit d’une défausse, pas d’une pioche. Sous-total ciblé : Semi-Pure 6 + Pung de Dragon 2 + Dernière Tuile Jetée 8.'},
 {id:'replacement-kong',title:'Gagner après un Kong',groups:[['C1','C2','C3'],['D2','D3','D4'],['B3','B4','B5!'],['C9','C9','C9','C9'],['D5','D5']],open:[3],win:'draw',special:'kongReplacement',target:[51,74,46],excluded:[80],
  context:'Le joueur déclare un Kong exposé de 9 Caractères. La tuile de remplacement obtenue après le Kong est le 5 Bambous gagnant. Il ne s’agit pas d’un remplacement de fleur.',
  ask:'Quel fan décrit cette victoire sur remplacement après Kong ?',correct:'Finir sur Kong',choices:['Finir sur Kong','Dernière Tuile Tirée','Voler le Kong','Tirer soi-même'],
  reason:'Finir sur Kong vaut 8 points pour une tuile gagnante de remplacement après Kong. Avec Trois Chows Superposés (6) et Kong exposé (1) : sous-total ciblé 15. D’autres fans de la main peuvent s’ajouter.'},
 {id:'robbing-kong',title:'Voler un Kong',groups:[['C1','C2','C3'],['D4','D5','D6'],['B7','B8','B9'],['C4','C5','C6!'],['D2','D2']],open:[0],win:'discard',special:'robKong',target:[39,63,47],
  context:'Un adversaire ajoute le 6 Caractères à son Pung exposé pour former un Kong. Le joueur intercepte ce 6 Caractères pour gagner ; ce n’est pas la dernière tuile du mur.',
  ask:'Comment appelle-t-on cette victoire ?',correct:'Voler le Kong',choices:['Voler le Kong','Finir sur Kong','Dernière Tuile Jetée','Dernière Tuile Tirée'],
  reason:'Voler le Kong vaut 8 points : la tuile gagnante est celle qu’un adversaire ajoute à un Pung exposé pour en faire un Kong. Il ne faut pas confondre avec la pioche de remplacement après un Kong. Sous-total ciblé : 8 + 2 + 8.'},
 {id:'double-wind',title:'Un vent qui compte double',groups:[['WS','WS','WS'],['DR','DR','DR'],['C2','C2','C2'],['B8','B8','B8'],['D5','D5!']],open:[0,1],win:'discard',special:'none',seatWind:'WS',prevWind:'WS',target:[49,60,61,59],excluded:[73],
  context:'Le Vent du joueur est Sud et le Vent dominant est également Sud. La main comprend un Pung de Sud et un Pung de Dragon rouge. Le joueur gagne sur défausse.',
  ask:'Quels fans de vent faut-il retenir pour le Pung de Sud ?',correct:'Vent du joueur + Vent dominant',choices:['Vent du joueur + Vent dominant','Pung de Vent ordinaire à 1 point','Vent dominant seulement','Vent du joueur seulement'],
  reason:'Le Pung de Sud rapporte Vent du joueur (2) + Vent dominant (2) : 4 points, sans ajouter Pung de Vent ordinaire (1). Sous-total ciblé : Tout Pung 6 + 2 + 2 + Pung de Dragon 2 = 12.'},
 {id:'melded-hand',title:'Tout est exposé… sauf l’attente',groups:[['C1','C2','C3'],['D2','D3','D4'],['B3','B4','B5'],['C6','C7','C8'],['D5','D5!']],open:[0,1,2,3],win:'discard',special:'none',target:[51,63,53],excluded:[79],
  context:'Les quatre figures ont été déclarées. Il reste seulement un 5 Cercles caché : la défausse du deuxième 5 Cercles complète la paire et la main.',
  ask:'Quel fan de 6 points s’applique à cette main entièrement exposée ?',correct:'Tout Exposé',choices:['Tout Exposé','Finir sur la Paire','Tout Caché Donné','Tout Caché Tiré'],
  reason:'Tout Exposé vaut 6 points lorsque les quatre figures sont déclarées et la paire complétée sur une défausse. Il implique Finir sur la Paire : ce dernier ne s’ajoute pas. Sous-total ciblé : 6 + 2 + 6.'},
 {id:'edge-only',title:'L’attente du côté',groups:[['C1','C2','C3!'],['D2','D3','D4'],['B3','B4','B5'],['C6','C7','C8'],['D5','D5']],open:[1,2,3],win:'discard',special:'none',target:[51,63,77],
  context:'Trois figures sont exposées et la paire est déjà complète. Le joueur attend uniquement le 3 Caractères pour compléter ses deux tuiles cachées 1-2 Caractères.',
  ask:'Quel fan d’attente s’applique ici ?',correct:'Finir d’un Côté',choices:['Finir d’un Côté','Finir au Milieu','Finir sur la Paire','Tirer soi-même'],
  reason:'Finir d’un Côté vaut 1 point : terminer le 1-2 par le 3 (ou le 8-9 par le 7) dans une attente réellement unique. Sous-total ciblé : 6 + 2 + 1.'}
];
function subTotal(scene){return scene.target.reduce((sum,id)=>sum+S[id].points,0);}
// Important : au niveau 5, les textes décrivent parfois une tuile précise (rang + famille).
// Toute permutation automatique des familles créerait des incohérences pédagogiques.
// On conserve donc ici les mains EXACTEMENT telles qu'elles sont définies dans CASES.
function instantiate(source){return {...source,groups:source.groups.map(g=>g.slice()),open:source.open.slice()};}
root.MCR_CHALLENGES={FANS:S,CASES,subTotal,instantiate};
})(typeof window==='undefined'?globalThis:window);
