import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const data=JSON.parse(fs.readFileSync(path.join(root,'audit/resources-manifest.json'),'utf8'));
const index=fs.readFileSync(path.join(root,'index.html'),'utf8');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
let checks=0;
function yes(ok,msg){if(!ok)throw Error(msg);checks++;}
yes(data.length===3,'Doit contenir trois ressources');
yes(index.includes('data-tab="ressources"'),'Onglet Ressources manquant');
yes(app.includes("if(page==='ressources')return renderResources();"),'Affichage Ressources non raccordé');
yes(sw.includes('mcr-trainer-v0.5.3'),'Cache non actualisé');
yes(app.includes("const STORAGE_KEY='mcr-trainer-v0.1'"),'Cle de sauvegarde modifiee');
for(const file of data){
 const bytes=fs.readFileSync(path.join(root,'ressources',file.filename));
 yes(bytes.subarray(0,5).toString()==='%PDF-','En-tête PDF incorrect : '+file.filename);
 yes(bytes.length===file.bytes,'Taille PDF modifiée : '+file.filename);
 yes(crypto.createHash('sha256').update(bytes).digest('hex')===file.sha256,'PDF altéré : '+file.filename);
 yes(app.includes('ressources/'+file.filename),'Lien manquant : '+file.filename);
 yes(sw.includes('./ressources/'+file.filename),'PDF absent du cache hors ligne : '+file.filename);
}
console.log(JSON.stringify({status:'PASS',resources:data.length,checks},null,2));
