/* MCR Trainer · curated V0.1 exercises. Fan numbers and values from the Green Book.
   Illustrations are teaching samples only: a fragment is not a scored winning hand. */
window.MCR_DATA = [
  {
    id:70,level:1,fr:'Double Chow',en:'Mixed Double Chow',points:1,kind:'fragment',
    groups:[['B3','B4','B5'],['D3','D4','D5']],
    prompt:'Deux chows de mêmes numéros, mais dans deux familles différentes : quel fan reconnais-tu ?',
    definition:'Deux chows identiques en valeur, dans deux familles différentes.',
    note:'Ne pas confondre avec Double Chow Pur : celui-ci reste dans la même famille.'
  },
  {
    id:73,level:1,fr:'Pung de Vent ou d’Extrémité',en:'Pung of Terminals or Honors',points:1,kind:'fragment',
    groups:[['C9','C9','C9'],['WE','WE','WE']],connectors:['ou'],
    prompt:'Un pung de 9 Caractères, ou un pung d’Est qui n’est ni ton Vent ni celui du tour : quel fan reconnais-tu ?',
    definition:'Un pung d’une tuile d’extrémité (1 ou 9) ou d’un vent éligible.',
    note:'Pour l’exemple du Vent d’Est à 1 point, on suppose qu’Est n’est ni le Vent du joueur ni le Vent dominant. Sinon, ce sont les fans Vent du joueur et/ou Vent dominant (2 points chacun) qui s’appliquent ; ne pas ajouter automatiquement ce point.'
  },
  {
    id:59,level:1,fr:'Pung de Dragon',en:'Dragon Pung',points:2,kind:'fragment',
    groups:[['DR','DR','DR']],
    prompt:'Trois dragons rouges forment un pung. Quel fan est directement concerné ?',
    definition:'Un pung d’un même dragon : rouge, vert ou blanc.',
    note:'Un pung de dragon vaut 2 points. Il ne faut pas le traiter comme un simple pung ordinaire.'
  },
  {
    id:76,level:1,fr:'Pas d’Honneur',en:'No Honors',points:1,kind:'main',
    groups:[['B3','B3','B3'],['C1','C2','C3'],['D4','D5','D6'],['B7','B8','B9'],['C5','C5']],
    prompt:'Cette main comporte un pung et trois chows, mais aucun honneur. Quel fan à 1 point peut s’y appliquer ?',
    definition:'Aucune tuile d’honneur (ni Vent, ni Dragon) dans la main.',
    note:'Attention : si la main est Tout Chow (2 points), Pas d’Honneur est déjà inclus et ne rapporte pas 1 point supplémentaire.'
  },
  {
    id:75,level:1,fr:'Une Famille Absente',en:'One Voided Suit',points:1,kind:'main',
    groups:[['C1','C2','C3'],['D3','D4','D5'],['C4','C5','C6'],['D7','D8','D9'],['D2','D2']],
    prompt:'Dans cette main, il n’y a aucun Bambou. Quel fan décrit cette absence ?',
    definition:'L’une des trois familles numérotées est entièrement absente.',
    note:'Une Famille Absente peut être exclu du décompte lorsqu’un fan supérieur l’implique, comme Semi-Pure.'
  },
  {
    id:63,level:1,fr:'Tout Chow',en:'All Chows',points:2,kind:'main',
    groups:[['C1','C2','C3'],['D3','D4','D5'],['B4','B5','B6'],['D7','D8','D9'],['C5','C5']],
    prompt:'Quatre chows et une paire de tuiles numérotées : quel fan décrit cette structure ?',
    definition:'Quatre chows et une paire sans honneurs.',
    note:'Tout Chow vaut 2 points pour quatre chows et une paire sans honneurs. N’ajoute pas Pas d’Honneur : il est inclus par définition.'
  },
  {
    id:80,level:1,fr:'Tirer soi-même',en:'Self-Drawn',points:1,kind:'situation',
    groups:[['D5!']],
    prompt:'Le joueur gagne grâce à la tuile qu’il vient de piocher. Quel fan de circonstance obtient-il ?',
    definition:'La tuile gagnante a été piochée par le joueur lui-même.',
    note:'Cette circonstance ne se déduit pas de la seule composition visible des tuiles.'
  },
  {
    id:69,level:2,fr:'Double Chow Pur',en:'Pure Double Chow',points:1,kind:'fragment',
    groups:[['B3','B4','B5'],['B3','B4','B5']],
    prompt:'Voici deux chows identiques dans la même famille : quel fan ?',
    definition:'Deux chows identiques dans la même famille.',
    note:'Le fan Double Chow (sans « Pur ») suppose au contraire deux familles différentes.'
  },
  {
    id:71,level:2,fr:'Petite Suite Pure',en:'Short Straight',points:1,kind:'fragment',
    groups:[['B1','B2','B3'],['B4','B5','B6']],
    prompt:'Deux chows qui se suivent, 1-2-3 puis 4-5-6 Bambous : quel fan ?',
    definition:'Deux chows successifs dans une même famille (six numéros consécutifs).',
    note:'C’est un motif de six tuiles, différent de la Grande Suite Pure de neuf tuiles.'
  },
  {
    id:72,level:2,fr:'Deux Chows Purs d’Extrémités',en:'Two Terminal Chows',points:1,kind:'fragment',
    groups:[['B1','B2','B3'],['B7','B8','B9']],
    prompt:'Le couple 1-2-3 et 7-8-9 apparaît dans une seule famille. Quel fan ?',
    definition:'Un chow 1-2-3 et un chow 7-8-9 dans la même famille.',
    note:'Ces deux chows doivent appartenir à une même famille numérotée.'
  },
  {
    id:78,level:2,fr:'Finir au Milieu',en:'Closed Wait',points:1,kind:'situation',
    groups:[['C1','C2!','C3']],
    prompt:'En supposant qu’il s’agit de l’unique attente de la main, le 2 gagnant complète 1-2-3. Quel fan ?', 
    definition:'La tuile gagnante est celle du milieu d’un chow.',
    note:'Le motif dessiné ne prouve pas l’attente unique. Ce fan est accordé uniquement si aucune autre tuile ne permettait de terminer la main entière.'
  },
  {
    id:79,level:2,fr:'Finir sur la Paire',en:'Single Wait',points:1,kind:'situation',
    groups:[['D5','D5!']],
    prompt:'Si cette tuile est la seule gagnante possible, elle complète la paire. Quel fan ?', 
    definition:'La tuile gagnante sert à compléter l’unique paire de la main.',
    note:'La paire doit être complétée par la seule tuile permettant de gagner ; une image de paire seule ne démontre pas cette attente unique.'
  },
  {
    id:77,level:2,fr:'Finir d’un Côté',en:'Edge Wait',points:1,kind:'situation',
    groups:[['C1','C2','C3!']],
    prompt:'Si c’est la seule attente gagnante, la tuile 3 complète 1-2. Quel fan ?', 
    definition:'Attendre le 3 pour compléter 1-2-3, ou le 7 pour compléter 7-8-9.',
    note:'La forme 1-2 attendant 3, ou 8-9 attendant 7, doit être la seule possibilité gagnante de la main entière.'
  },
  {
    id:62,level:2,fr:'Tout Caché Donné',en:'Concealed Hand',points:2,kind:'situation',
    groups:[['C1','C2','C3'],['D4','D5','D6'],['B4','B5','B6'],['C7','C8','C9'],['D5','D5!']],
    prompt:'Aucun élément déclaré, puis victoire sur défausse. Quel fan de 2 points ?',
    definition:'Gagner sur une défausse sans avoir exposé de chow, pung ou kong.',
    note:'La victoire sur pioche, sans élément exposé, relève d’un autre fan : Tout Caché Tiré (4 points).'
  },
  {
    id:51,level:3,fr:'Trois Chows Superposés',en:'Mixed Shifted Chows',points:6,kind:'fragment',
    groups:[['C1','C2','C3'],['D2','D3','D4'],['B3','B4','B5']],
    prompt:'Trois chows dans trois familles, décalés chacun d’un numéro : quel fan de 6 points ?',
    definition:'Trois chows, un dans chaque famille, dont les premières tuiles ont des valeurs consécutives (décalage d’un rang exactement).',
    note:'Le décalage de deux rangs n’est pas autorisé ici : il est réservé au fan n° 30 Trois Chows Purs Superposés, dans une seule famille. Ne pas confondre avec Triple Chow ni Grande Suite.'
  },
  {
    id:52,level:3,fr:'Tout Type',en:'All Types',points:6,kind:'main',
    groups:[['C1','C2','C3'],['B4','B5','B6'],['D6','D7','D8'],['WS','WS','WS'],['DR','DR']],
    prompt:'Cette main contient Caractères, Cercles, Bambous, Vent et Dragon. Quel fan ?',
    definition:'Présence des trois familles numérotées, d’au moins un Vent et d’au moins un Dragon.',
    note:'Tous les cinq types doivent être présents : trois familles, Vents et Dragons.'
  },
  {
    id:50,level:3,fr:'Semi-Pure',en:'Half Flush',points:6,kind:'main',
    groups:[['C1','C2','C3'],['C4','C5','C6'],['C7','C8','C9'],['DR','DR','DR'],['WE','WE']],
    prompt:'Une seule famille numérotée, accompagnée de Vents et Dragons : quel fan ?',
    definition:'Une seule famille numérotée dans la main, avec des honneurs.',
    note:'Ne pas ajouter Une Famille Absente : il est impliqué par Semi-Pure.'
  },
  {
    id:49,level:3,fr:'Tout Pung',en:'All Pungs',points:6,kind:'main',
    groups:[['C2','C2','C2'],['D5','D5','D5'],['B8','B8','B8'],['DR','DR','DR'],['WE','WE']],
    prompt:'Cette main est constituée de quatre pungs et d’une paire. Quel fan ?',
    definition:'Quatre pungs (ou kongs) et une paire.',
    note:'La présence d’un kong est compatible avec cette structure.'
  },
  {
    id:39,level:3,fr:'Grande Suite',en:'Mixed Straight',points:8,kind:'fragment',
    groups:[['C1','C2','C3'],['D4','D5','D6'],['B7','B8','B9']],
    prompt:'1-2-3, 4-5-6 et 7-8-9 répartis dans trois familles : quel fan ?',
    definition:'Une grande suite 1 à 9 répartie sur les trois familles numérotées.',
    note:'Ne pas confondre avec Grande Suite Pure, où les trois chows appartiennent à une seule famille.'
  },
  {
    id:28,level:3,fr:'Grande Suite Pure',en:'Pure Straight',points:16,kind:'fragment',
    groups:[['B1','B2','B3'],['B4','B5','B6'],['B7','B8','B9']],
    prompt:'Les trois chows 1-2-3, 4-5-6 et 7-8-9 sont tous en Bambous : quel fan ?',
    definition:'Les trois chows 1-2-3, 4-5-6 et 7-8-9 dans une seule famille.',
    note:'Le fan vaut 16 points : mémorise sa différence avec Grande Suite, qui vaut 8 points.'
  },
];
window.MCR_LEVELS = [
 {id:1,eyebrow:'LE POINT DE DÉPART',title:'Reconnaître les essentiels',desc:'Sept fans à repérer rapidement : structure, honneurs et circonstances.',theme:'Découverte',icon:'✦'},
 {id:2,eyebrow:'LES DÉTAILS QUI COMPTENT',title:'Affiner ton regard',desc:'Attentes, chows voisins et main cachée : ne pas confondre les motifs.',theme:'Reconnaissance',icon:'◈'},
 {id:3,eyebrow:'LES STRUCTURES GAGNANTES',title:'Viser les huit points',desc:'Les grandes bases de 6, 8 et 16 points, avec leurs exclusions.',theme:'Calcul',icon:'◆'},
 {id:4,eyebrow:'LA LOGIQUE DU DÉCOMPTE',title:'Associer les fans',desc:'Dix mains complètes, cumuls autorisés et fans déjà inclus : apprendre à compter sans doublons.',theme:'Cumuls et exclusions',icon:'◇'},
 {id:5,eyebrow:'LE DÉFI FINAL',title:'Défis MCR',desc:'Dix mains complètes, circonstances de victoire, sous-totaux ciblés et mode chronométré libre.',theme:'Situations avancées',icon:'✧'},
];
window.MCR_SOURCES = [
 {title:'Règles MCR, Green Book (WMO)',url:'https://mahjong-europe.org/portal/index.php?Itemid=167&id=31&option=com_content&view=article'},
 {title:'Traduction française du Green Book',url:'https://mahjong.loolai.com/wp-content/uploads/2018/07/greenbook_traduction.pdf'},
 {title:'MahjongSoft · Handbook, stratégie et observations',url:'https://mahjongsoft.com/files/Book_MCR_ENG_3.pdf'}
];
